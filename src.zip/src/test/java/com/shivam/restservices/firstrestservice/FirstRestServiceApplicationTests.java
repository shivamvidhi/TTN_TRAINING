package com.shivam.restservices.firstrestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstRestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
