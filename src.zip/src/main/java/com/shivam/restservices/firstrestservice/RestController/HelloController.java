package com.shivam.restservices.firstrestservice.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

// Controller
@RestController
public class HelloController {

    //Get
    //URI
    //Method
    @RequestMapping(method = RequestMethod.GET, path = "/hello")
    public String Hello()
    {
        return "Welcome to Spring Boot";
    }
}
