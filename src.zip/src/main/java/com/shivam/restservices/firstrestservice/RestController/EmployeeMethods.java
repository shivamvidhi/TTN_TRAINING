package com.shivam.restservices.firstrestservice.RestController;


import com.shivam.restservices.firstrestservice.Exceptions.EmployeeNotFound;
import com.shivam.restservices.firstrestservice.Model.Employee;
import com.shivam.restservices.firstrestservice.Service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.util.*;

@RestController
public class EmployeeMethods {

    @Autowired
    EmployeeService employeeService;



    // find All Employees
    @GetMapping("/Employees")
    public List<Employee> list()
    {
       return  employeeService.findAll();
    }



    // find Particular Employee

    @GetMapping("Employee/{id}")
    public Employee get(@PathVariable int id)

    {
        Employee e = employeeService.getParticularEmployee(id);
        if(e == null)
        {
            throw new EmployeeNotFound("id"+ id+"Not found");
        }
        return e;
    }

    // saving the employee
    @PostMapping("/Employee")
    public Employee save(@RequestBody Employee e)
    {
        return employeeService.save(e);
    }

    @PostMapping("/Employee2")
    public ResponseEntity<Object> giveStatus(@Valid @RequestBody Employee e)
    {
        Employee ee = employeeService.save(e);
        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(ee.getId()).toUri();
        return ResponseEntity.created(location).build();
    }


    // deleting an Employee

    @DeleteMapping("/Employee/{id}")
    public void delete(@PathVariable int id)
    {
        Employee user = employeeService.delete(id);

        if(user==null)
            throw new EmployeeNotFound("id-"+ id);
    }

}
